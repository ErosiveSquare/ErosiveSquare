import numpy as np
import cv2
import os

os.environ['YOLO_VERBOSE'] = str(False)
from ultralytics import YOLO
from pathlib import Path
from boxmot.trackers.botsort.StableBotsort2 import Stablebotsort2
from boxmot import BoTSORT, StableBoTSORT
import os
import pandas as pd
import torch
import multiprocessing

os.environ['CUDA_VISIBLE_DEVICES'] = str(1)
# import cfgs
# from models import *
from multiprocessing import Pool
import time
import math


def calculate_iou(box1, box2):
    """
    计算两个边界框的交并比(Intersection over Union)

    参数:
    box1, box2: [x_min, y_min, x_max, y_max]

    返回:
    float: 交并比值
    """
    # 计算重叠区域的坐标
    x_left = max(box1[0], box2[0])
    y_top = max(box1[1], box2[1])
    x_right = min(box1[2], box2[2])
    y_bottom = min(box1[3], box2[3])

    # 计算重叠区域的面积
    intersection_area = max(0, x_right - x_left) * max(0, y_bottom - y_top)

    # 计算两个边界框的面积
    box1_area = (box1[2] - box1[0]) * (box1[3] - box1[1])
    box2_area = (box2[2] - box2[0]) * (box2[3] - box2[1])

    # 计算并集面积
    union_area = box1_area + box2_area - intersection_area

    # 计算IoU
    iou = intersection_area / union_area if union_area > 0 else 0
    return iou


def box_label(image, box, label='', color=(128, 128, 128), txt_color=(255, 255, 255)):
    # 在图像上绘制边界框和标签
    p1, p2 = (int(box[0]), int(box[1])), (int(box[2]), int(box[3]))
    cv2.rectangle(image, p1, p2, color, thickness=1, lineType=cv2.LINE_AA)
    if label:
        w, h = cv2.getTextSize(label, 0, fontScale=0.2, thickness=1)[0]
        outside = p1[1] - h >= 3
        p2 = p1[0] + w, p1[1] - h - 3 if outside else p1[1] + h + 3
        cv2.rectangle(image, p1, p2, color, -1, cv2.LINE_AA)
        cv2.putText(image,
                    label, (p1[0], p1[1] - 2 if outside else p1[1] + h + 2),
                    0, 0.2, txt_color, thickness=1, lineType=cv2.LINE_AA)


def process_video(input_video_path, output_video_dir, output_gallery_dir, output_excel_dir, save_video, device_id):
    # 选择GPU
    device = torch.device(f'cuda:{device_id}' if torch.cuda.is_available() else 'cpu')
    print(f"处理视频: {input_video_path}, 使用设备: {device}")

    # 处理单个视频的多进程函数
    os.makedirs(output_video_dir, exist_ok=True)
    os.makedirs(output_excel_dir, exist_ok=True)
    video_filename = os.path.basename(input_video_path)
    video_filename_without_ext = os.path.splitext(video_filename)[0]
    output_video_path = os.path.join(output_video_dir, f'out_{video_filename_without_ext}.mp4')
    output_excel_path = os.path.join(output_excel_dir, f'{video_filename_without_ext}.xlsx')

    output_gallery_dir = os.path.join(output_gallery_dir, f'{video_filename_without_ext}')

    # 判断output_gallery_dir是否已经存在，若存在则直接返回
    # if os.path.exists(output_gallery_dir):
    #     print(f"输出目录 {output_gallery_dir} 已存在，跳过处理.")

    os.makedirs(output_gallery_dir, exist_ok=True)

    try:
        print("正在加载模型")
        with torch.cuda.device(device_id):
            print("正在加载模型")
            model = YOLO('E:\BoT-SORT\yolov8m.pt', task='detect')
            print("YOLO加载成功")

        cap = cv2.VideoCapture(input_video_path)

        # 检查视频是否成功打开
        if not cap.isOpened():
            print(f"无法打开视频: {input_video_path}")
            return False

        fps = cap.get(cv2.CAP_PROP_FPS)
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        print(f"视频信息 - FPS: {fps}, 宽度: {width}, 高度: {height}")

        videoWriter = None
        if save_video:
            fourcc = cv2.VideoWriter_fourcc(*'XVID')
            videoWriter = cv2.VideoWriter(output_video_path, fourcc, fps, (width, height))

        tracker = BoTSORT(
            model_weights=Path('E:\BoT-SORT\clip_zhz.pt'),
            # 车辆reid模型'VehicleID_clipreid_ViT-B-16_60.pt'
            device=device_id,
            # half=False,
            fp16=False,
            track_buffer=200
        )

        image_info_list = []
        frame_counter = 0
        continuous_id_counter = 0
        PERSON_CLASS_ID = 0
        track_history = {}

        while cap.isOpened():
            success, frame = cap.read()
            if not success:
                print(f"无法读取视频帧, 视频读取结束: {input_video_path}")
                break
            frame_counter += 1
            print(f"处理帧 {frame_counter} - 宽度: {frame.shape[1]}, 高度: {frame.shape[0]}")

            results = model(frame, conf=0.2)
            # print(f"Results[0].boxes: {results[0].boxes}")
            outputs = results[0].boxes.data.cpu().numpy()
            # print('---------------------------------------')

            if outputs is not None and len(outputs) > 0:
                person_detections = outputs[outputs[:, 5] == PERSON_CLASS_ID]
                if len(person_detections) > 0:
                    dets = np.column_stack([
                        person_detections[:, :4],
                        person_detections[:, 4],
                        np.zeros(len(person_detections))
                    ])

                    # 过滤重叠的边界框
                    filtered_dets = []
                    for i, det in enumerate(dets):
                        is_valid = True
                        for j, other_det in enumerate(dets):
                            if i != j:
                                # 如果IoU超过阈值(例如0.9)，则不跟踪
                                if calculate_iou(det[:4], other_det[:4]) > 0.9:
                                    is_valid = False
                                    break
                        if is_valid:
                            filtered_dets.append(det)

                    # 使用过滤后的检测框
                    filtered_dets = np.array(filtered_dets)
                    tracks = tracker.update(filtered_dets, frame)
                    # if len(person_detections) > 0:
                    #     dets = np.column_stack([
                    #         person_detections[:, :4],
                    #         person_detections[:, 4],
                    #         np.zeros(len(person_detections))
                    #     ])
                    #     tracks = tracker.update(dets, frame)



                    for track in tracks:
                        bbox = track[:4]
                        track_id = int(track[4])
                        confidence = track[5]
                        if track_id not in track_history:
                            track_history[track_id] = continuous_id_counter
                            continuous_track_id = continuous_id_counter
                            continuous_id_counter += 1
                        else:
                            continuous_track_id = track_history[track_id]
                        x_min = max(0, int(bbox[0]))
                        y_min = max(0, int(bbox[1]))
                        x_max = min(frame.shape[1], int(bbox[2]))
                        y_max = min(frame.shape[0], int(bbox[3]))
                        if x_max > x_min and y_max > y_min:
                            cropped_img = frame[y_min:y_max, x_min:x_max]
                            if cropped_img.size > 0:
                                os.makedirs(f'{output_gallery_dir}/{continuous_track_id}', exist_ok=True)
                                cropped_filename = f'{output_gallery_dir}/{continuous_track_id}/video_{video_filename_without_ext}_frame_{frame_counter}_person_{continuous_track_id}.jpg'
                                cv2.imwrite(cropped_filename, cropped_img)
                                norm_x1 = x_min / width
                                norm_y1 = y_min / height
                                norm_x2 = x_max / width
                                norm_y2 = y_max / height
                                image_info_list.append({
                                    'image_path': cropped_filename,
                                    'frame': frame_counter,
                                    'id': continuous_track_id,
                                    'BBox': [round(norm_x1, 5), round(norm_y1, 5), round(norm_x2, 5), round(norm_y2, 5)]
                                })

                                box_label(frame, bbox, f'#{continuous_track_id}', (167, 146, 11))
            if save_video and videoWriter is not None:
                videoWriter.write(frame)

        cap.release()
        if videoWriter is not None:
            videoWriter.release()

        if image_info_list:
            pd.DataFrame(image_info_list).to_excel(output_excel_path, index=False)
        return True
    except Exception as e:
        print(f"处理视频 {input_video_path} 时出错: {e}")
        return False


def batch_process_videos(
        txt_file_path,
        output_video_dir,
        output_gallery_dir,
        output_excel_dir,
        save_video=True,
        num_gpus=2,
        gpu_id=0
):
    os.makedirs(output_video_dir, exist_ok=True)
    os.makedirs(output_gallery_dir, exist_ok=True)
    os.makedirs(output_excel_dir, exist_ok=True)

    # 从txt文件中读取所有视频路径
    with open(txt_file_path, 'r') as f:
        video_files = [line.strip() for line in f.readlines() if line.strip()]  # 去除空行和无效路径

    successful_videos = 0  # 记录成功处理的视频数

    # 按顺序处理每个视频
    for video_file in video_files:
        result = process_video(
            video_file,
            output_video_dir,
            output_gallery_dir,
            output_excel_dir,
            save_video,
            gpu_id  # GPU 0
        )
        successful_videos += result  # 如果处理成功，增加成功数量

    print(f"处理完成: 成功 {successful_videos}/{len(video_files)} 个视频。")


if __name__ == "__main__":
    multiprocessing.set_start_method('spawn')
    input_video_dir = "E:\BoT-SORT\input.txt"
    output_video_dir = r"E:\BoT-SORT\output\video"
    output_gallery_dir = "E:\BoT-SORT\output\gallery"
    output_excel_dir = "E:\BoT-SORT\output\excel"
    batch_process_videos(input_video_dir, output_video_dir, output_gallery_dir, output_excel_dir, save_video=True)
