import numpy as np
import cv2
import os

from boxmot.trackers.botsort.StableBotsort2 import Stablebotsort2
from boxmot.trackers.botsort.Wbotsort import Wbotsort

os.environ['YOLO_VERBOSE'] = str(False)
os.environ['CUDA_VISIBLE_DEVICES'] = '0'  # 使用物理 GPU 0
from ultralytics import YOLO
from pathlib import Path

from boxmot.trackers.botsort.bot_sort import BoTSORT
import pandas as pd
import torch

if __name__ == "__main__":
    device = torch.device(f'cuda:0' if torch.cuda.is_available() else 'cpu')
    print(f"使用设备: {device}")

    sequence_dir = r"E:\BoT-SORT\data\MOT17\train\MOT17-02-DPM\img1"
    output_file = "results/MOT17-02-DPM.txt"
    os.makedirs(os.path.dirname(output_file), exist_ok=True)  # 创建目录

    try:
        print("加载模型中...")
        with torch.cuda.device(0):
            model = YOLO('E:\BoT-SORT\yolov8m.pt', task='detect')
            print("YOLO 加载成功")

        tracker = BoTSORT(
            model_weights=Path('E:\BoT-SORT\clip_zhz.pt'),
            device=0,
            fp16=False,
            track_buffer=60
        )

        PERSON_CLASS_ID = 0  # 假设 YOLO 行人类别索引为 0（COCO 数据集）

        with open(output_file, "w") as f:
            for frame_idx, img_path in enumerate(sorted(os.listdir(sequence_dir)), start=1):
                frame = cv2.imread(os.path.join(sequence_dir, img_path))
                if frame is None:
                    print(f"无法读取帧: {img_path}")
                    continue

                # YOLO 检测
                results = model(frame, conf=0.2)
                outputs = results[0].boxes.data.cpu().numpy()

                if outputs.shape[0] > 0:
                    # 过滤行人检测框
                    person_detections = outputs[outputs[:, 5] == PERSON_CLASS_ID]
                    if person_detections.shape[0] > 0:
                        dets = np.column_stack([
                            person_detections[:, :4],  # x1, y1, x2, y2
                            person_detections[:, 4],   # conf
                            np.zeros(len(person_detections))  # 占位符
                        ])
                        tracks = tracker.update(dets, frame)

                        # 写入跟踪结果
                        for track in tracks:
                            x1, y1, x2, y2 = map(int, track[:4])
                            w = x2 - x1
                            h = y2 - y1
                            track_id = int(track[4])
                            # 确保坐标不越界
                            x1 = max(0, min(x1, frame.shape[1] - 1))
                            y1 = max(0, min(y1, frame.shape[0] - 1))
                            w = max(1, min(w, frame.shape[1] - x1))
                            h = max(1, min(h, frame.shape[0] - y1))
                            f.write(f"{frame_idx},{track_id},{x1},{y1},{w},{h},1,1,1\n")
                            print({frame_idx},{track_id},{x1},{y1},{w},{h},1,1,1)
                else:
                    tracks = []

    except Exception as e:
        print(f"处理失败: {str(e)}")